import os
from glob import glob
from pathlib import Path

tar_folder = r"/DATA1/dl/DL316_22_23_2/grp11/DomainNet/painting"

dirs = os.listdir(tar_folder)

out_dir = r"/DATA1/dl/DL316_22_23_2/grp11/ActiveLearning-SDM-main/DomainNet"

file_path = os.path.join(out_dir,Path(tar_folder).name+".txt")
with open(file_path,'w') as src:
    for id, dir in enumerate(dirs):
        files = glob(os.path.join(tar_folder,dir,"*.jpg"))
        for file in files:
            src.writelines(str(file)+"  "+str(id)+"\n")


    