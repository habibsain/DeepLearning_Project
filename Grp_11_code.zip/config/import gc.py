import gc

del variable #delete unnecessary variables 
gc.collect()